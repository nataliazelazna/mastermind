
#include "game.hpp"

int main(){
    Game g;
    g.playMastermind();
}